# Forest Landing Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/robertgbaptista/pen/jOZGEWX](https://codepen.io/robertgbaptista/pen/jOZGEWX).

Animated landing page using Adobe Illustrator, Github, HTML and CSS. Thanks to Online Tutorials on YouTube for the tutorial.

Forest graphics designed by brgfx / Freepik.

